import React from 'react';
import './notes.css';
import DarkGreySvg from './dark_grey_svg';
import EditButton from "./edit_button";
import NoNotes from "./no_notes";

function Notes() {
  return (
    <div className="notes">
        <div className="notes_div">
         <div className="title_notes">
           NOTES
             <DarkGreySvg/>
             <EditButton/>
         </div>
            <NoNotes label="No Notes"/>
        </div>
    </div>
  );
}

export default Notes;
