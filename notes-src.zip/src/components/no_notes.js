import React from 'react';
import './no_notes.css';

function NoNotes(props) {
    return (
        <div className="no_notes">{props.label}</div>
    )
}

export default NoNotes;