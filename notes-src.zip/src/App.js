import './App.css';
import Notes from "./components/notes";

function App() {
  return (
    <div className="App">
      <Notes/>
    </div>
  );
}

export default App;
