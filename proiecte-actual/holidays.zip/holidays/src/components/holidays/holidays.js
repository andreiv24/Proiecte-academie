import HolidaysGroup from './holidays_group';
import React from 'react';
import './holidays.css';

function Holidays() {
    return (
        <div className="holidays_whitecontainer">
          <label className="bank_holidays_label">BANK HOLIDAYS - 2021</label>
          <HolidaysGroup holiday_date="01.01.2021" holiday_dateweek="Friday" holiday_type="Revelion"/>
          <HolidaysGroup holiday_date="02.01.2021" holiday_dateweek="Saturday" holiday_type="Revelion"/>
          <HolidaysGroup holiday_date="24.01.2021" holiday_dateweek="Sunday" holiday_type="Unirea Principatelor Unite"/>
          <HolidaysGroup holiday_date="30.04.2021" holiday_dateweek="Friday" holiday_type="Vinerea Mare"/>
          <HolidaysGroup holiday_date="01.05.2021" holiday_dateweek="Saturday" holiday_type="Paste"/>
          <HolidaysGroup holiday_date="02.05.2021" holiday_dateweek="Sunday" holiday_type="Paste"/>
          <HolidaysGroup holiday_date="03.05.2021" holiday_dateweek="Monday" holiday_type="Ziua Muncii"/>
          <HolidaysGroup holiday_date="01.06.2021" holiday_dateweek="Tuesday" holiday_type="Ziua Copilului"/>
          <HolidaysGroup holiday_date="20.06.2021" holiday_dateweek="Sunday" holiday_type="Rusaliile"/>
          <HolidaysGroup holiday_date="21.06.2021" holiday_dateweek="Monday" holiday_type="Rusaliile"/>
          <HolidaysGroup holiday_date="15.09.2021" holiday_dateweek="Sunday" holiday_type="Adormirea Maicii Domnului"/>
          <HolidaysGroup holiday_date="30.11.2021" holiday_dateweek="Tuesday" holiday_type="Sfantul Andrei"/>
          <HolidaysGroup holiday_date="01.12.2021" holiday_dateweek="Wednesday" holiday_type="Ziua Nationala a Romaniei"/>
          <HolidaysGroup holiday_date="25.12.2021" holiday_dateweek="Saturday" holiday_type="Craciun"/>
          <HolidaysGroup holiday_date="26.12.2021" holiday_dateweek="Sunday" holiday_type="Craciun"/>
        </div>
    )
}

export default Holidays;