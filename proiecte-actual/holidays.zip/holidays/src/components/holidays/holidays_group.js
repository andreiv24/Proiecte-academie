import React from 'react';
import './holidays_group.css';

function HolidaysGroup(props) {
    return (
        <div className="holidays_group">
            <div className="holiday_date">{props.holiday_date}</div>
            <div className="holiday_dateweek">{props.holiday_dateweek}</div>
            <div className="holiday_type">{props.holiday_type}</div>
          </div>
    )
}

export default HolidaysGroup;