import React from 'react';
import './labelbold_gi.css';

function LabelBold(props) {
    return (
        <div className="labelbold_gi">{props.label}</div>
    )
}

export default LabelBold;