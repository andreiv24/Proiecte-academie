import React from 'react';
import './label_gi.css';

function Label(props) {
    return (
        <div className="label_gi">{props.label}</div>
    )   
}

export default Label;