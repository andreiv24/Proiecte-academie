import React from 'react';
import './overview.css';
import LabelBold from './labelbold_gi';
import Label from './label_gi';

function Overview() {
  return (
    <div className="overview">
      <div className="gen_information">
         <div className="title_gi">
           GENERAL INFORMATION
         <button className="edit_button">Edit</button>
         </div>
         <div className="username_gi">Name Username</div>
         <div className="email_gi">nameusername@gmail.com</div>
         <LabelBold label="Employee Number"/>
         <div className="group_gi">
         <LabelBold label="Location"/>
           <Label label="Main Location"/>
         </div>
         <LabelBold label="Department"/>
         <p className="space_gi"> </p>
         <div className="group_gi">
         <LabelBold label="Approver"/>
           <Label label="Approves own absences"/>
           <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
 <path d="M7.00016 0.333496C3.32016 0.333496 0.333496 3.32016 0.333496 7.00016C0.333496 10.6802 3.32016 13.6668 7.00016 13.6668C10.6802 13.6668 13.6668 10.6802 13.6668 7.00016C13.6668 3.32016 10.6802 0.333496 7.00016 0.333496ZM7.66683 11.6668H6.3335V10.3335H7.66683V11.6668ZM9.04683 6.50016L8.44683 7.1135C7.96683 7.60016 7.66683 8.00016 7.66683 9.00016H6.3335V8.66683C6.3335 7.9335 6.6335 7.26683 7.1135 6.78016L7.94016 5.94016C8.18683 5.70016 8.3335 5.36683 8.3335 5.00016C8.3335 4.26683 7.7335 3.66683 7.00016 3.66683C6.26683 3.66683 5.66683 4.26683 5.66683 5.00016H4.3335C4.3335 3.52683 5.52683 2.3335 7.00016 2.3335C8.4735 2.3335 9.66683 3.52683 9.66683 5.00016C9.66683 5.58683 9.42683 6.12016 9.04683 6.50016Z" fill="#ABABAB"/>
 </svg>
         </div>
         <div className="group_gi">
         <LabelBold label="Role"/>
           <Label label="Owner"/>
           <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
 <path d="M7.00016 0.333496C3.32016 0.333496 0.333496 3.32016 0.333496 7.00016C0.333496 10.6802 3.32016 13.6668 7.00016 13.6668C10.6802 13.6668 13.6668 10.6802 13.6668 7.00016C13.6668 3.32016 10.6802 0.333496 7.00016 0.333496ZM7.66683 11.6668H6.3335V10.3335H7.66683V11.6668ZM9.04683 6.50016L8.44683 7.1135C7.96683 7.60016 7.66683 8.00016 7.66683 9.00016H6.3335V8.66683C6.3335 7.9335 6.6335 7.26683 7.1135 6.78016L7.94016 5.94016C8.18683 5.70016 8.3335 5.36683 8.3335 5.00016C8.3335 4.26683 7.7335 3.66683 7.00016 3.66683C6.26683 3.66683 5.66683 4.26683 5.66683 5.00016H4.3335C4.3335 3.52683 5.52683 2.3335 7.00016 2.3335C8.4735 2.3335 9.66683 3.52683 9.66683 5.00016C9.66683 5.58683 9.42683 6.12016 9.04683 6.50016Z" fill="#ABABAB"/>
 </svg>
         </div>
         <div className="group_gi">
         <LabelBold label="Allowed to approve"/>
           <Label label="Yes"/>
           <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
 <path d="M7.00016 0.333496C3.32016 0.333496 0.333496 3.32016 0.333496 7.00016C0.333496 10.6802 3.32016 13.6668 7.00016 13.6668C10.6802 13.6668 13.6668 10.6802 13.6668 7.00016C13.6668 3.32016 10.6802 0.333496 7.00016 0.333496ZM7.66683 11.6668H6.3335V10.3335H7.66683V11.6668ZM9.04683 6.50016L8.44683 7.1135C7.96683 7.60016 7.66683 8.00016 7.66683 9.00016H6.3335V8.66683C6.3335 7.9335 6.6335 7.26683 7.1135 6.78016L7.94016 5.94016C8.18683 5.70016 8.3335 5.36683 8.3335 5.00016C8.3335 4.26683 7.7335 3.66683 7.00016 3.66683C6.26683 3.66683 5.66683 4.26683 5.66683 5.00016H4.3335C4.3335 3.52683 5.52683 2.3335 7.00016 2.3335C8.4735 2.3335 9.66683 3.52683 9.66683 5.00016C9.66683 5.58683 9.42683 6.12016 9.04683 6.50016Z" fill="#ABABAB"/>
 </svg>
         </div>
         <p className="space_gi"> </p>
         <div className="group_gi">
         <LabelBold label="Status"/>
           <Label label="Active"/>
         </div>
         <div className="group_gi">
         <LabelBold label="Language"/>
           <Label label="English"/>
         </div>
       </div>
    </div>
  );
}

export default Overview;
