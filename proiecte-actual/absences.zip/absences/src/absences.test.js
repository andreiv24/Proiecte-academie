import { render, screen } from '@testing-library/react';
import Absences from './absences';

test('renders learn react link', () => {
  render(<Absences />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
