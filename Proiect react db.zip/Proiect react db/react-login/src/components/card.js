import React from 'react';
import Login from './login_form';
import Register from './register_form';
import './card.css';

function Card() {
    return (
    <div className="card">
      <Login/>
      <Register/>
    </div>
    )
}

export default Card;