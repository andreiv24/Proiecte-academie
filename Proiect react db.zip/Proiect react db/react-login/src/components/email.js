import React from 'react';
import './email.css';

function Email(props) {
    return(
    <div className="email_group">
        <label className='email_text'>{props.label}</label>
        <input type='text' placeholder={props.placeholder} className='email_input'></input>
    </div>
    )
}

export default Email;