import React from 'react';
import './register_name.css';

function Name(props) {
    return (
        <>
        <div className='name_group'>
            <div className="name_texts">
                <label className='name_label'>{props.name}</label>
            </div>
            <input type='text' placeholder={props.nameplaceholder} className='name_input'></input>
        </div>
        {/* <div className='name_group'>
            <div className="name_texts">
                <label className='name_label'>First Name *</label>
            </div>
            <input type='text' placeholder='First Name' className='name_input'></input>
        </div>
        <div className='name_group'>
            <div className="name_texts">
                <label className='name_label'>Last Name *</label>
            </div>
            <input type='text' placeholder='Last Name' className='name_input'></input>
        </div> */}
        </>
    )
}

export default Name;