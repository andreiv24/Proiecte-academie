import React from 'react';
import './register_privileges.css';

function RegisterPrivileges (props) {
    return (
        <>
        <div className='privileges_text'>{props.label}</div>
            <select className='privileges'>
            <option value="0">{props.label0}</option>
            <option value="1">{props.label1}</option>
            <option value="2">{props.label2}</option>
            <option value="3">{props.label3}</option>
            </select>
        </>
    )
}

export default RegisterPrivileges;