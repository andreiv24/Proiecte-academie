import React from 'react'
import Title from './title';
import Name from './register_name';
import Email from './email';
import Password from './password';
import RegisterPrivileges from './register_privileges';
import Button from './button';

function Register () {
    return (
        <form className='register_form'>
            <Title label="Create Account"/>
            <div className='name_inputs'>
                <Name name="First Name *" nameplaceholder="First Name"/>
                <Name name="Last Name *" nameplaceholder="Last Name"/>
            </div>
            <Email label="Email *" placeholder="Email"/>
            <Password label="" label1="Password" placeholder="Password"/>
            <div className='privileges_group'>
                <RegisterPrivileges label="Privileges" label0="Select:" label1="Admin" label2="Team Leader" label3="Angajat"/>
                <RegisterPrivileges label="Functions" label0="Select:" label1="Admin" label2="Team Leader" label3="Angajat"/>
            </div>
            <Button label="REGISTER"/>
    </form>
    )
}

export default Register;