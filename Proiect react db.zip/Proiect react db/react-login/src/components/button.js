import React from 'react';
import './button.css';

function Button(props) {
    return (
        <div className='button_div'> 
          <button className='button'>
            <div className="button_text">{props.label}</div>
            </button>
          </div>
    )
}

export default Button;