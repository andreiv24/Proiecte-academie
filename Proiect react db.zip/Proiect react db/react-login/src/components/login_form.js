import React from 'react';
import Title from './title';
import Email from './email';
import Password from './password';
import Button from './button';

function Login() {
    return (
        <form class='login_form'>
        <Title label="Login to your account"/>
        <Email label="Email" placeholder="Email"/>
        <Password label="Forgot your password?" label1="Password" placeholder="Password"/>
        <Button label="LOG IN"/>
      </form>
    )
}

export default Login;