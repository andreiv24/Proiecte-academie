import './App.css';
import Card from './components/card.js';

function App() {
  return (
      <Card/>
  );
}

export default App;
