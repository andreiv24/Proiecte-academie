import React from 'react'
import './cancel_button_sp.css'

function CancelButtonSP() {
    return (
        <button className="cancel_button_sp">Cancel</button>  
    )
}

export default CancelButtonSP;