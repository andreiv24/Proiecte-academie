import React from 'react'
import './save_button_sp.css'

function SaveButtonSP() {
    return (
        <button className="save_button_sp">Save</button>  
    )
}

export default SaveButtonSP;