import React from 'react';
import './labelbold_gi.css';

function LabelBoldGI(props) {
    return (
        <div className="labelbold_gi">{props.label}</div>
    )
}

export default LabelBoldGI;