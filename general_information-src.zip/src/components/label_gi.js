import React from 'react';
import './label_gi.css';

function LabelGI(props) {
    return (
        <div className="label_gi">{props.label}</div>
    )   
}

export default LabelGI;