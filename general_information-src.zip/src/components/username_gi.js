import React from "react";
import './username_gi.css'

function UsernameGI(props) {
    return (
        <div className="username_gi">{props.label}</div>
    )
}

export default UsernameGI;