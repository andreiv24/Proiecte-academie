import { render, screen } from '@testing-library/react';
import General_information from './general_information';

test('renders learn react link', () => {
  render(<General_information />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
