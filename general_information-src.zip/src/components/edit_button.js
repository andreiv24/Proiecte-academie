import React from "react";
import './edit_button.css';

function EditButton() {
    return (
        <button className="edit_button">Edit</button>
    )
}
export default EditButton;