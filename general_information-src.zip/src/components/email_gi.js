import React from "react";
import './email_gi.css'

function EmailGI(props) {
    return (
        <div className="email_gi">{props.label}</div>
    )
}

export default EmailGI;