import React from 'react';
import './general_information.css';
import LabelBoldGI from './labelbold_gi';
import LabelGI from './label_gi';
import GreySvg from './grey_svg';
import EditButton from "./edit_button";
import UsernameGI from "./username_gi";
import EmailGI from "./email_gi";

function GeneralInformation() {
  return (
    <div className="general_information">
      <div className="general_information_div">
         <div className="title_gi">
           GENERAL INFORMATION
             <EditButton/>
         </div>
          <UsernameGI label="Name Username"/>
          <EmailGI label="nameusername@gmail.com"/>
         <LabelBoldGI label="Employee Number"/>
         <div className="group_gi">
         <LabelBoldGI label="Location"/>
           <LabelGI label="Main Location"/>
         </div>
         <LabelBoldGI label="Department"/>
         <p className="space_gi"> </p>
         <div className="group_gi">
         <LabelBoldGI label="Approver"/>
           <LabelGI label="Approves own absences"/>
             <GreySvg/>
         </div>
         <div className="group_gi">
         <LabelBoldGI label="Role"/>
           <LabelGI label="Owner"/>
           <GreySvg/>
         </div>
         <div className="group_gi">
         <LabelBoldGI label="Allowed to approve"/>
           <LabelGI label="Yes"/>
           <GreySvg/>
         </div>
         <p className="space_gi"> </p>
         <div className="group_gi">
         <LabelBoldGI label="Status"/>
           <LabelGI label="Active"/>
         </div>
         <div className="group_gi">
         <LabelBoldGI label="Language"/>
           <LabelGI label="English"/>
         </div>
       </div>
    </div>
  );
}

export default GeneralInformation;
