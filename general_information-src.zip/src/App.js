import './App.css';
import GeneralInformation from "./components/general_information";

function App() {
  return (
    <div className="App">
      <GeneralInformation/>
    </div>
  );
}

export default App;
