import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <div className="header">
        <div className="absence_text1">ALL (1)</div>
        <div className="absence_text2">OPEN (0)</div>
        <div className="absence_text3">UPCOMING ABCENCES (1)</div>
        <div className="absence_text4">DECLINED (0)</div>
      </div>
    </div>
  );
}

export default App;
