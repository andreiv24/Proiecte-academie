import Holidays from './components/holidays/holidays';
import './App.css';

function App() {
  return (
    <div className="App">
        <Holidays/>
    </div>
  );
}

export default App;
